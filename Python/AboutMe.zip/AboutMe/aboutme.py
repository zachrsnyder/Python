print('Zachary Snyder')
print('I am a sophomore at the University of Missouri studying computer sceince. ')
print('I like to workout, play videogames, and listen to music.\nIm from the Lake of the Ozarks. I loved growing up there and its even more fun as an adult.')
